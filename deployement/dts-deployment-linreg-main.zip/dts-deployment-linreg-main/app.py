from flask import Flask, request, render_template, jsonify
import joblib
import numpy as np
from sklearn.preprocessing import StandardScaler

# Muat model dan scaler yang telah disimpan
kmeans = joblib.load('model.pkl')
scaler = joblib.load('scaler_model.pkl')

# Inisialisasi aplikasi Flask
app = Flask(__name__)

# Route untuk halaman utama (formulir input)
@app.route('/')
def home():
    return render_template('index.html')

# Route untuk melakukan prediksi klaster (POST request dari formulir)
@app.route('/predict', methods=['POST'])
def predict():
    try:
        # Ambil data input dari formulir
        usia = float(request.form['Usia'])
        pstv05 = float(request.form['PSTV05'])
        pstv09 = float(request.form['PSTV09'])
        fkrtl = float(request.form['FKRTL'])
        fktp = float(request.form['FKTP'])

        # Preprocess data dan normalisasi
        input_data = np.array([[usia, pstv05, pstv09, fkrtl, fktp]])
        input_data_scaled = scaler.transform(input_data)

        # Prediksi klaster
        cluster = kmeans.predict(input_data_scaled)

        # Tentukan strategi intervensi berdasarkan klaster
        if cluster[0] == 0:
            intervention_strategy = "Fokus pada pendidikan kesehatan preventif, penyuluhan, dan pemeriksaan rutin untuk mengurangi risiko TB."
        elif cluster[0] == 1:
            intervention_strategy = "Menyediakan perawatan lanjutan, dengan edukasi tentang pengelolaan penyakit TB dan meningkatkan akses ke FKRTL."
        else:
            intervention_strategy = "Meningkatkan deteksi dini, akses lebih awal ke layanan kesehatan, dan program penyuluhan untuk pencegahan penyakit TB."

        # Tampilkan hasil prediksi dan strategi intervensi
        return render_template('index.html', prediction=cluster[0], intervention_strategy=intervention_strategy)

    except Exception as e:
        return f"Error: {e}"

if __name__ == "__main__":
    app.run(debug=True)
